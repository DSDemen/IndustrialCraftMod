function on_placed(x, y, z)
    if get_block(x, y, z + 1) == block_index('industrialcraft:Active_Wire') then
        set_block(x, y, z, block_index('industrialcraft:If_active'), get_block_states(x, y, z))
        return
    elseif get_block(x, y, z - 1) == block_index('industrialcraft:Active_Wire') then
        set_block(x, y, z, block_index('industrialcraft:If_active'), get_block_states(x, y, z))
        return
    elseif get_block(x, y + 1, z) == block_index('industrialcraft:Active_Wire') then
        set_block(x, y, z, block_index('industrialcraft:If_active'), get_block_states(x, y, z))
        return
    elseif get_block(x, y - 1, z) == block_index('industrialcraft:Active_Wire') then
        set_block(x, y, z, block_index('industrialcraft:If_active'), get_block_states(x, y, z))
        return
    elseif get_block(x + 1, y, z) == block_index('industrialcraft:Active_Wire') then
        set_block(x, y, z, block_index('industrialcraft:If_active'), get_block_states(x, y, z))
        return
    elseif get_block(x - 1, y, z) == block_index('industrialcraft:Active_Wire') then
        set_block(x, y, z, block_index('industrialcraft:If_active'), get_block_states(x, y, z))
        return
    end
end

function on_update(x, y, z)
    if get_block(x, y, z + 1) == block_index('industrialcraft:Active_Wire') then
        set_block(x, y, z, block_index('industrialcraft:If_active'), get_block_states(x, y, z))
        return
    elseif get_block(x, y, z - 1) == block_index('industrialcraft:Active_Wire') then
        set_block(x, y, z, block_index('industrialcraft:If_active'), get_block_states(x, y, z))
        return
    elseif get_block(x, y + 1, z) == block_index('industrialcraft:Active_Wire') then
        set_block(x, y, z, block_index('industrialcraft:If_active'), get_block_states(x, y, z))
        return
    elseif get_block(x, y - 1, z) == block_index('industrialcraft:Active_Wire') then
        set_block(x, y, z, block_index('industrialcraft:If_active'), get_block_states(x, y, z))
        return
    elseif get_block(x + 1, y, z) == block_index('industrialcraft:Active_Wire') then
        set_block(x, y, z, block_index('industrialcraft:If_active'), get_block_states(x, y, z))
        return
    elseif get_block(x - 1, y, z) == block_index('industrialcraft:Active_Wire') then
        set_block(x, y, z, block_index('industrialcraft:If_active'), get_block_states(x, y, z))
        return
    end
end
