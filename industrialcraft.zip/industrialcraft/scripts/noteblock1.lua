function on_place(x, y, z)


local audio1 = audio.loadSound("noteblock1.wav")
local audio1Channel = audio.play(audio1)



end