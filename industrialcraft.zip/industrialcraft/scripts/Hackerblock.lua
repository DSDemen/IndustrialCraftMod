function on_placed(x, y, z)

        set_block(x, y, z, block_index('core:air'), get_block_states(x, y, z))
        set_block(x, y-1, z, block_index('core:air'), get_block_states(x, y, z))
        
 
end