function on_update(x, y, z)
    if get_block(x, y-1, z) ~= block_index('base:grass_block') then
        set_block(x, y, z, block_index('core:air'), get_block_states(x, y, z))
        set_block(x, y-1, z, block_index('industrialcraft:sand'), get_block_states(x, y, z))
        return
    end
end