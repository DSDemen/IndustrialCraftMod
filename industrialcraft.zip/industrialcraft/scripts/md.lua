

function on_broken(x, y, z)
    local id = block_index('industrialcraft:md')
    if get_block(x, y+1, z) == id then
        set_block(x, y+1, z, 0)
    end
    if get_block(x, y-1, z) == id then
        set_block(x, y-1, z, 0)
    end    
end

function on_placed(x, y, z)
    if is_replaceable_at(x, y+1, z) then
        set_block(x, y+1, z, get_block(x, y, z), get_block_states(x, y, z))
    else
        set_block(x, y, z, 0, 0)
    end
end