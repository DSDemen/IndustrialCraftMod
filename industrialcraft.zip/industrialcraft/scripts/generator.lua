function on_interact(x, y, z)

   set_block(x,y,z, block_index('industrialcraft:generator2'), get_block_states(x, y, z))

end