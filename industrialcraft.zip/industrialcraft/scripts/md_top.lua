

function on_broken(x, y, z)
    set_block(x, y-1, z, 0)
end