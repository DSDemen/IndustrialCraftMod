

function on_broken(x, y, z)
    local id = block_index('industrialcraft:md_open')
    if get_block(x, y+1, z) == id then
        set_block(x, y+1, z, 0)
    end
    if get_block(x, y-1, z) == id then
        set_block(x, y-1, z, 0)
    end    
end