

function on_broken(x, y, z)
    set_block(x, y+1, z, 0)
end

function on_update(x, y, z)
    if get_block(x, y, z + 1) ~= block_index('industrialcraft:rb') then
       set_block(x, y+1, z, block_index('industrialcraft:md_top'), get_block_states(x, y+1, z))
       set_block(x, y, z, block_index('industrialcraft:md_bottom'), get_block_states(x, y, z))
       return
    elseif get_block(x, y, z - 1) ~= block_index('industrialcraft:rb') then
       set_block(x, y+1, z, block_index('industrialcraft:md_top'), get_block_states(x, y+1, z))
       set_block(x, y, z, block_index('industrialcraft:md_bottom'), get_block_states(x, y, z))
       return
    elseif get_block(x, y + 1, z) ~= block_index('industrialcraft:rb') then
       set_block(x, y+1, z, block_index('industrialcraft:md_top'), get_block_states(x, y+1, z))
       set_block(x, y, z, block_index('industrialcraft:md_bottom'), get_block_states(x, y, z))
       return
    elseif get_block(x, y - 1, z) ~= block_index('industrialcraft:rb') then
       set_block(x, y+1, z, block_index('industrialcraft:md_top'), get_block_states(x, y+1, z))
       set_block(x, y, z, block_index('industrialcraft:md_bottom'), get_block_states(x, y, z))
       return
    elseif get_block(x + 1, y, z) ~= block_index('industrialcraft:rb') then
       set_block(x, y+1, z, block_index('industrialcraft:md_top'), get_block_states(x, y+1, z))
       set_block(x, y, z, block_index('industrialcraft:md_bottom'), get_block_states(x, y, z))
       return
    elseif get_block(x - 1, y, z) ~= block_index('industrialcraft:rb') then
       set_block(x, y+1, z, block_index('industrialcraft:md_top'), get_block_states(x, y+1, z))
       set_block(x, y, z, block_index('industrialcraft:md_bottom'), get_block_states(x, y, z))
       return
    end
end
